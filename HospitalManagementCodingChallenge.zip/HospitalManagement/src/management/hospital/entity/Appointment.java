package management.hospital.entity;

import java.time.LocalDate;
import java.util.Objects;

public class Appointment {

	private int appointmentid;
	private int patientid;
	private int doctorid;
	private LocalDate appointmentdate;
	private String description;

	public Appointment() {
		super();
	}

	public Appointment(int patientid, int doctorid, LocalDate appointmentdate, String description) {
		super();
		this.patientid = patientid;
		this.doctorid = doctorid;
		this.appointmentdate = appointmentdate;
		this.description = description;
	}

	public Appointment(int appointmentid, int patientid, int doctorid, LocalDate appointmentdate, String description) {
		super();
		this.appointmentid = appointmentid;
		this.patientid = patientid;
		this.doctorid = doctorid;
		this.appointmentdate = appointmentdate;
		this.description = description;
	}
	
	

	public int getAppointmentid() {
		return appointmentid;
	}

	public void setAppointmentid(int appointmentid) {
		this.appointmentid = appointmentid;
	}

	public int getPatientid() {
		return patientid;
	}

	public void setPatientid(int patientid) {
		this.patientid = patientid;
	}

	public int getDoctorid() {
		return doctorid;
	}

	public void setDoctorid(int doctorid) {
		this.doctorid = doctorid;
	}

	public LocalDate getAppointmentdate() {
		return appointmentdate;
	}

	public void setAppointmentdate(LocalDate appointmentdate) {
		this.appointmentdate = appointmentdate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		return Objects.hash(appointmentdate, appointmentid, description, doctorid, patientid);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Appointment other = (Appointment) obj;
		return Objects.equals(appointmentdate, other.appointmentdate) && appointmentid == other.appointmentid
				&& Objects.equals(description, other.description) && doctorid == other.doctorid
				&& patientid == other.patientid;
	}

	@Override
	public String toString() {
		return "Appointment [appointmentid=" + appointmentid + ", patientid=" + patientid + ", doctorid=" + doctorid
				+ ", appointmentdate=" + appointmentdate + ", description=" + description + "]";
	}

}
