package management.hospital.entity;

import java.util.Objects;

public class Doctor {
	
	private int doctorid;
	private String firstname;
	private String lastname;
	private String specialization;
	private String contactnumber;
	public Doctor() {
		super();
	}
	public Doctor(int doctorid, String firstname, String lastname, String specialization, String contactnumber) {
		super();
		this.doctorid = doctorid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.specialization = specialization;
		this.contactnumber = contactnumber;
	}
	public Doctor(String firstname, String lastname, String specialization, String contactnumber) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.specialization = specialization;
		this.contactnumber = contactnumber;
	}
	public int getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(int doctorid) {
		this.doctorid = doctorid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	@Override
	public int hashCode() {
		return Objects.hash(contactnumber, doctorid, firstname, lastname, specialization);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		return Objects.equals(contactnumber, other.contactnumber) && doctorid == other.doctorid
				&& Objects.equals(firstname, other.firstname) && Objects.equals(lastname, other.lastname)
				&& Objects.equals(specialization, other.specialization);
	}
	@Override
	public String toString() {
		return "Doctor [doctorid=" + doctorid + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", specialization=" + specialization + ", contactnumber=" + contactnumber + "]";
	}
	
	

}
