package management.hospital.entity;

import java.time.LocalDate;
import java.util.Objects;

public class Patient {

	private int patientId;
	private String firstname;
	private String lastname;
	private LocalDate dateofbirth;
	private String gender;
	private String phonenumber;
	private String address;

	public Patient() {
		super();
	}

	public Patient(String firstname, String lastname, LocalDate dateofbirth, String gender, String phonenumber,
			String address) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.dateofbirth = dateofbirth;
		this.gender = gender;
		this.phonenumber = phonenumber;
		this.address = address;
	}

	public Patient(int patientId, String firstname, String lastname, LocalDate dateofbirth, String gender,
			String phonenumber, String address) {
		super();
		this.patientId = patientId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dateofbirth = dateofbirth;
		this.gender = gender;
		this.phonenumber = phonenumber;
		this.address = address;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, dateofbirth, firstname, gender, lastname, patientId, phonenumber);
	}
	

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public LocalDate getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(LocalDate dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		return Objects.equals(address, other.address) && Objects.equals(dateofbirth, other.dateofbirth)
				&& Objects.equals(firstname, other.firstname) && Objects.equals(gender, other.gender)
				&& Objects.equals(lastname, other.lastname) && patientId == other.patientId
				&& Objects.equals(phonenumber, other.phonenumber);
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", dateofbirth=" + dateofbirth + ", gender=" + gender + ", phonenumber=" + phonenumber + ", address="
				+ address + "]";
	}

}
