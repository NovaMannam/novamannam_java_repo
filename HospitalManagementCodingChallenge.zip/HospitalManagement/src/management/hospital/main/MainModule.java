package management.hospital.main;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import manaagement.hospital.exception.PatientNumberNotFoundException;
import management.hospital.dao.HospitalServiceImpl;
import management.hospital.dao.IHospitalService;
import management.hospital.entity.Appointment;
import management.hospital.entity.Doctor;
import management.hospital.entity.Patient;

public class MainModule {

	public static void main(String[] args) throws PatientNumberNotFoundException, ClassNotFoundException, SQLException {
		IHospitalService hospitalservice = new HospitalServiceImpl();
		
		int c1 = -1;
		
		
		int patientid = 0;
		String pfirstname = null;
		String plastname = null;
		LocalDate dateofbirth = null;
		String gender = null;
		String pcontactnumber = null;
		String address = null;
		
		int doctorid = 0;
		String dfirstname = null;
		String dlastname = null;
		String specialization = null;
		String dcontactnumber = null;
		
		
		int appointmentid = 0;
		LocalDate appointmentdate = null;
		String description = null;
		
		Scanner sc = new Scanner(System.in);
		outer : 
		while (c1 != 0) {
			System.out.println("Menu:");

			System.out.println("1. Add Patient Details :");
			System.out.println("2. Add Doctor Details");
			System.out.println("3. Add Appointment Details");

			System.out.println("4. Get Appoinment Details by Appointment Id :");
			System.out.println("5. Get Appoinment Details by Patient Id :");
			System.out.println("6. Get Appoinment Details by Doctor Id :");
			System.out.println("7. Schedule Appointment :");
			System.out.println("8. Update Appointment :");
			System.out.println("9. Cancel Appointment");
			System.out.println("0. Quit : ");
			System.out.println("Enter your choice :");

			c1 = sc.nextInt();
			sc.nextLine();

			switch (c1) {
			case 1: {
				System.out.println("Enter First Name of the Patient:");
				pfirstname = sc.nextLine();
				System.out.println("Enter Last Name of the Patient");
				plastname = sc.nextLine();
				System.out.println("Enter the date of birth of the patient in yyyy-MM-dd format:");
				String dob = sc.nextLine();
				dateofbirth = null;

				DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");

				try {
					dateofbirth = LocalDate.parse(dob, df);
				} catch (Exception e) {
					System.out.println("Invalid date format. Please enter the date in the format yyyy-MM-dd.");
				}
				System.out.println("Enter Gender");
				gender = sc.nextLine();
				System.out.println("Enter phonenumber : ");
				pcontactnumber = sc.nextLine();
				System.out.println("Enter the Address : ");
				address = sc.nextLine();

				Patient patient = new Patient(pfirstname, plastname, dateofbirth, gender, pcontactnumber, address);

				int success = 0;

				try {
					success = hospitalservice.addPatient(patient);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (success == 1) {
					System.out.println("Inserted SuccessfullY");
				}
				break;

			}
			case 2: {

				System.out.println("Enter First Name of the doctor:");
				dfirstname = sc.nextLine();
				System.out.println("Enter Last Name of the doctor");
				dlastname = sc.nextLine();
				System.out.println("Enter the Specilization :");
				specialization = sc.nextLine();
				System.out.println("Enter the phonenumber");
				dcontactnumber = sc.nextLine();

				Doctor doctor = new Doctor(dfirstname, dlastname, specialization, dcontactnumber);

				int success = 0;

				try {
					success = hospitalservice.addDoctor(doctor);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (success == 1) {
					System.out.println("Inserted SuccessfullY");
				}
				break;

			}
			case 3: {
				System.out.println("Enter the patient id:");
				patientid = sc.nextInt();
				System.out.println("Enter the doctor id");
				doctorid = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter Appointment date in yyyy-MM-dd format : ");
				String adate = sc.nextLine();
				appointmentdate = null;
				DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				try {
					appointmentdate = LocalDate.parse(adate, df);
				} catch (Exception e) {
					System.out.println("Invalid date format. Please enter the date in the format yyyy-MM-dd.");
				}
				System.out.println("Enter the Description :");
				description = sc.nextLine();

				Appointment appointment = new Appointment(patientid, doctorid, appointmentdate, description);

				int success = 0;

				try {
					success = hospitalservice.addAppointment(appointment);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (success == 1) {
					System.out.println("Inserted SuccessfullY");
				}
				break;
			}
			case 4: {
				System.out.println("Enter the appointment id");
				int n = sc.nextInt();
				Appointment appointment = null;
				try {
					appointment = hospitalservice.getAppointmentById(n);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (PatientNumberNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println("No record Found : ");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (appointment == null) {
					System.out.println("No Appointment For Given Patient Id");
				}
				System.out.println(appointment);
				break;
			}
			case 5: {
				System.out.println("Enter the Patient Id");
				int n = sc.nextInt();
				List<Appointment> al = null;
				try {
					al = hospitalservice.getAppointmentsForPatient(n);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (PatientNumberNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println("No record Found : ");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (al == null) {
					System.out.println("NO Appointment Found : ");
				} else {
					System.out.println(al);

				}
				break;
			}
			case 6: {
				System.out.println("Enter the doctor id");
				int n = sc.nextInt();
				List<Appointment> dl = null;
				try {
					dl = hospitalservice.getAppointmentsForDoctor(n);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (PatientNumberNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println("No record Found : ");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (dl == null) {
					System.out.println("NO Appointment Found : ");
				} else {
					System.out.println(dl);

				}
				break;

			}
			case 7: {
				Appointment appointment = new Appointment();
				if (hospitalservice.scheduleAppointment(appointment)) {
					System.out.println("Appointment Scheduled Successfully : ");

				} else {
					System.out.println("Looks like there is an error in scheduling an appointment: ");
				}
				break;
			}
			case 8: {
						System.out.println("Enter the appointment id");
						appointmentid = sc.nextInt();			
						System.out.println("Enter the patient id:");
						patientid = sc.nextInt();
						System.out.println("Enter the doctor id");
						doctorid = sc.nextInt();
						sc.nextLine();
						System.out.println("Enter Appointment date in yyyy-MM-dd format");
						String adate = sc.nextLine();
						appointmentdate = null;
						DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						try {
							appointmentdate = LocalDate.parse(adate, df);
						} catch (Exception e) {
							System.out.println("Invalid date format. Please enter the date in the format yyyy-MM-dd.");
						}
						System.out.println("Enter the Description :");
						description = sc.nextLine();

						Appointment appointment = new Appointment(appointmentid,patientid, doctorid, appointmentdate, description);
						
						if(hospitalservice.updateAppointment(appointment))
						{
							System.out.println("Updated Successfully : ");
						}
						else
						{
							System.out.println("Updation of details is not successfull :");
						}

				
				break;
			}
			case 9: {
				System.out.println("Enter the Appointment id to delete : ");
				int n = sc.nextInt();
				if (hospitalservice.cancelAppointment(n)) {
					System.out.println("Appointment Canceled Successfully : ");
				} else {
					throw new PatientNumberNotFoundException("Not Found ");
				}
				break;
			}
			case 0 :
			{
				System.out.println("Quitting the application : ");
				break outer;
			}
			}

		}

	}

}
