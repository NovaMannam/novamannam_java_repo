package management.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import manaagement.hospital.exception.PatientNumberNotFoundException;
import management.hospital.entity.Appointment;
import management.hospital.entity.Doctor;
import management.hospital.entity.Patient;

public interface IHospitalService {

	public int addPatient(Patient patient) throws ClassNotFoundException, SQLException;

	public int addDoctor(Doctor doctor) throws ClassNotFoundException, SQLException;

	public int addAppointment(Appointment appointment) throws ClassNotFoundException, SQLException;

	public Appointment getAppointmentById(int apppointmentid)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException;

	public List<Appointment> getAppointmentsForPatient(int patientid)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException;

	public List<Appointment> getAppointmentsForDoctor(int doctorid)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException;

	public boolean scheduleAppointment(Appointment appointment)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException;

	public boolean updateAppointment(Appointment appointment)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException;;

	public boolean cancelAppointment(int appointmentid)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException;

}
