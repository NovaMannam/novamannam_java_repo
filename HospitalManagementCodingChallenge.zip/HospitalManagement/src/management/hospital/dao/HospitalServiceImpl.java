package management.hospital.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import manaagement.hospital.exception.PatientNumberNotFoundException;
import management.hospital.entity.Appointment;
import management.hospital.entity.Doctor;
import management.hospital.entity.Patient;
import management.hospital.util.DBUtil;

public class HospitalServiceImpl implements IHospitalService {
	Scanner sc = new Scanner(System.in);

	public static Connection hospitalconnect;

	@Override
	public Appointment getAppointmentById(int apppointmentid)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException {

		Appointment appointment = null;
		int patientid = 0;
		int doctorid = 0;
		LocalDate appointmentdate = null;
		String description = null;

		hospitalconnect = DBUtil.createConnection();

		String query = "SELECT * FROM appointment WHERE appointmentid = ?";

		PreparedStatement prepareStHospital = hospitalconnect.prepareStatement(query);

		prepareStHospital.setInt(1, apppointmentid);

		ResultSet rsHospital = prepareStHospital.executeQuery();

		while (rsHospital.next()) {// Till there are further records.
			apppointmentid = rsHospital.getInt("appointmentid");
			doctorid = rsHospital.getInt("doctorid");
			appointmentdate = rsHospital.getObject("appointmentdate", LocalDate.class);

			description = rsHospital.getString("description");

			appointment = new Appointment(patientid, doctorid, appointmentdate, description);
			appointment.setAppointmentid(apppointmentid);
		}

		DBUtil.closeConnection();

		if (appointment == null) {
			throw new PatientNumberNotFoundException("No Appointment Found For Particular Patient Id :\n");
		}

		return appointment;
	}

	@Override
	public List<Appointment> getAppointmentsForPatient(int patientid)
			throws PatientNumberNotFoundException, ClassNotFoundException, SQLException {

		List<Appointment> appointments = new ArrayList<>();
		Appointment appointment = null;

		int appointmentid = 0;
		int doctorid = 0;
		LocalDate appointmentdate = null;
		String description = null;

		hospitalconnect = DBUtil.createConnection();

		String query = "SELECT * FROM appointment where patientid = ?";

		PreparedStatement prepareStHospital = hospitalconnect.prepareStatement(query);
		prepareStHospital.setInt(1, patientid);

		ResultSet rsHospital = prepareStHospital.executeQuery();

		while (rsHospital.next()) {// Till there are further records.
			appointmentid = rsHospital.getInt("appointmentid");
			doctorid = rsHospital.getInt("doctorid");
			appointmentdate = rsHospital.getObject("appointmentdate", LocalDate.class);
			description = rsHospital.getString("description");
			appointment = new Appointment(appointmentid, patientid, doctorid, appointmentdate, description);

			appointments.add(appointment);
		}
		DBUtil.closeConnection();

		if (appointments.size() == 0) {
			throw new PatientNumberNotFoundException("No Patient Found");
		}

		return appointments;
	}

	@Override
	public List<Appointment> getAppointmentsForDoctor(int doctorid)
			throws ClassNotFoundException, SQLException, PatientNumberNotFoundException {
		List<Appointment> appointments = new ArrayList<>();
		Appointment appointment = null;

		int appointmentid = 0;
		int patientid = 0;
		LocalDate appointmentdate = null;
		String description = null;

		hospitalconnect = DBUtil.createConnection();

		String query = "SELECT * FROM appointment where doctorid = ?";

		PreparedStatement prepareStHospital = hospitalconnect.prepareStatement(query);
		prepareStHospital.setInt(1, doctorid);

		ResultSet rsHospital = prepareStHospital.executeQuery();

		while (rsHospital.next()) {// Till there are further records.
			appointmentid = rsHospital.getInt("appointmentid");
			doctorid = rsHospital.getInt("doctorid");
			appointmentdate = rsHospital.getObject("appointmentdate", LocalDate.class);
			description = rsHospital.getString("description");
			appointment = new Appointment(appointmentid, patientid, doctorid, appointmentdate, description);

			appointments.add(appointment);
		}
		DBUtil.closeConnection();

		if (appointments.size() == 0) {
			throw new PatientNumberNotFoundException("No Patient Found");
		}

		return appointments;
	}

	@Override
	public boolean scheduleAppointment(Appointment appointment) throws ClassNotFoundException, SQLException {

		hospitalconnect = DBUtil.createConnection();

		System.out.println("Enter the patient id:");
		int patientid = sc.nextInt();
		System.out.println("Enter the doctor id");
		int doctorid = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Appointment date");
		String adate = sc.nextLine();
		LocalDate appointmentdate = null;
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		try {
			appointmentdate = LocalDate.parse(adate, df);
		} catch (Exception e) {
			System.out.println("Invalid date format. Please enter the date in the format yyyy-MM-dd.");
		}
		System.out.println("Enter the Description :");
		String description = sc.nextLine();

		hospitalconnect = DBUtil.createConnection();
		String query = "INSERT INTO appointment(patientid, doctorid, appointmentdate ,description) "
				+ "VALUES(?,?,?,?)";

		PreparedStatement prepareSthospital = hospitalconnect.prepareStatement(query);
		prepareSthospital.setInt(1, patientid);
		prepareSthospital.setInt(2, doctorid);
		LocalDate localDate = appointmentdate;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDate = localDate.format(formatter);
		prepareSthospital.setString(3, formattedDate);
		prepareSthospital.setString(4, description);

		int result = prepareSthospital.executeUpdate();

		DBUtil.closeConnection();
		if (result == 1) {
			return true;
		}

		return false;
	}

	@Override
	public boolean updateAppointment(Appointment appointment) throws SQLException, ClassNotFoundException {
				
		hospitalconnect = DBUtil.createConnection();
		String query = "UPDATE appointment SET patientid=?, doctorid=?, appointmentdate=?, description=? "
				+ "WHERE appointmentid=?";
		
		
		Date appointmentdate = Date.valueOf(appointment.getAppointmentdate());
		
		PreparedStatement prepareStHospital = hospitalconnect.prepareStatement(query);
		prepareStHospital.setInt(1, appointment.getPatientid());
		prepareStHospital.setInt(2, appointment.getDoctorid());
		prepareStHospital.setDate(3, appointmentdate);
		prepareStHospital.setString(4, appointment.getDescription());
		prepareStHospital.setInt(5, appointment.getAppointmentid());
		
		int result = prepareStHospital.executeUpdate();

		DBUtil.closeConnection();
			
		if(result==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean cancelAppointment(int appointmentid) throws ClassNotFoundException, SQLException, PatientNumberNotFoundException {
		Appointment appointment = null; 
		int patientid = 0;
		int doctorid = 0;
		LocalDate appointmentdate = null;
		String description = null;
		
		int result = 0;
		
		hospitalconnect = DBUtil.createConnection();
 
		String queryCheck = "SELECT * FROM appointment WHERE appointmentid = ?";
		String queryDelete = "DELETE FROM appointment WHERE appointmentid = ?";
		
		PreparedStatement prepareStHospital = hospitalconnect.prepareStatement(queryCheck);
		PreparedStatement prepareAppointmentDelete = hospitalconnect.prepareStatement(queryDelete);
		
		prepareStHospital.setInt(1, appointmentid);
		prepareAppointmentDelete.setInt(1, appointmentid);
		
		ResultSet rs = prepareStHospital.executeQuery();
 
		while (rs.next()) {// Till there are further records.
			appointmentid = rs.getInt("appointmentid");
			patientid = rs.getInt("patientid");
			doctorid = rs.getInt("doctorid");
			appointmentdate = rs.getObject("appointmentdate", LocalDate.class);
			description = rs.getString("description");
 
			appointment = new Appointment(patientid,doctorid,appointmentdate,description);
			appointment.setAppointmentid(appointmentid);
		}
 
		if (appointment == null) {
			throw new PatientNumberNotFoundException("No Appointment found");
		}else {
			result = prepareAppointmentDelete.executeUpdate();
		}
 
		DBUtil.closeConnection();
		
		if(result==1)
		{
			return true;
		}
		return false;
	}

	@Override
	public int addPatient(Patient patient) throws ClassNotFoundException, SQLException {
		hospitalconnect = DBUtil.createConnection();
		String query = "INSERT INTO patient(firstname, lastname, dateofbirth,gender,contactnumber,address) "
				+ "VALUES(?,?,?,?,?,?)";

		PreparedStatement prepareSthospital = hospitalconnect.prepareStatement(query);
		prepareSthospital.setString(1, patient.getFirstname());
		prepareSthospital.setString(2, patient.getLastname());
		LocalDate localDate = patient.getDateofbirth();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDate = localDate.format(formatter);
		prepareSthospital.setString(3, formattedDate);
		prepareSthospital.setString(4, patient.getGender());
		prepareSthospital.setString(5, patient.getPhonenumber());
		prepareSthospital.setString(6, patient.getAddress());

		int result = prepareSthospital.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int addDoctor(Doctor doctor) throws ClassNotFoundException, SQLException {
		hospitalconnect = DBUtil.createConnection();
		String query = "INSERT INTO doctor(firstname, lastname, specialization ,contactnumber) " + "VALUES(?,?,?,?)";

		PreparedStatement prepareSthospital = hospitalconnect.prepareStatement(query);
		prepareSthospital.setString(1, doctor.getFirstname());
		prepareSthospital.setString(2, doctor.getLastname());
		prepareSthospital.setString(3, doctor.getSpecialization());
		prepareSthospital.setString(4, doctor.getContactnumber());

		int result = prepareSthospital.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int addAppointment(Appointment appointment) throws ClassNotFoundException, SQLException {
		hospitalconnect = DBUtil.createConnection();
		String query = "INSERT INTO appointment(patientid, doctorid, appointmentdate ,description) "
				+ "VALUES(?,?,?,?)";

		PreparedStatement prepareSthospital = hospitalconnect.prepareStatement(query);
		prepareSthospital.setInt(1, appointment.getPatientid());
		prepareSthospital.setInt(2, appointment.getDoctorid());
		LocalDate localDate = appointment.getAppointmentdate();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDate = localDate.format(formatter);
		prepareSthospital.setString(3, formattedDate);
		prepareSthospital.setString(4, appointment.getDescription());

		int result = prepareSthospital.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

}
